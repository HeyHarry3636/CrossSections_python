Read Me

To set up the ArcToolbox:

Copy/Save the folder 'StreamCrossSections' on your local drive somewhere.
-Desktop/Documents, etc.

You must move both the 'CrossSections.tbx' and Script folder together
-As the script folder is relatively tied to the ArcToolbox